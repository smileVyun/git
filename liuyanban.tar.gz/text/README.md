flask-guestbook
===============
最简单的Flask 留言板

使用Python 的 shelve 做为存储。

#TODO 修改成 MySQL 或者 Redis 存储。
