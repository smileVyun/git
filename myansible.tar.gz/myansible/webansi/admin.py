from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Group, Host, Module, Args

admin.site.register(Group)
admin.site.register(Host)
admin.site.register(Module)
admin.site.register(Args)