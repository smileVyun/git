from django.conf.urls import url
from . import views1

urlpatterns = [
    url(r'^$', views1.index, name='index'),
    url(r'^addhosts/$', views1.addhosts, name='addhosts'),
    url(r'^addmodules/$', views1.addmodules, name='addmodules'),
    url(r'^tasks/$', views1.tasks, name='tasks'),
]